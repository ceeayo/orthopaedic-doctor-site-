// Register
document.addEventListener("DOMContentLoaded", () => {
  const regForm = document.getElementById("registerForm");
  if (regForm) {
    regForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const username = document.getElementById("regUsername").value;
      const password = document.getElementById("regPassword").value;

      if (username && password) {
        localStorage.setItem(username, password);
        alert("Account created successfully!");
        window.location.href = "login.html";
      } else {
        alert("Please fill in all fields.");
      }
    });
  }

  const loginForm = document.getElementById("loginForm");
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const username = document.getElementById("loginUsername").value;
      const password = document.getElementById("loginPassword").value;

      const storedPassword = localStorage.getItem(username);
      if (storedPassword === password) {
        alert("Login successful!");
        window.location.href = "dashboard.html";
      } else {
        alert("Invalid username or password");
      }
    });
  }
});
